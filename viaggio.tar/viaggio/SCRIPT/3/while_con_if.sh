#!/bin/bash


while :
	do 
		
		read -p "Devo contnuare? [Y/N]" a;
		if [[ $a = "N" || $a = "n" ]];
		then
			break;
		fi
	done

echo -e "Grazie per aver fermato!	\n";
