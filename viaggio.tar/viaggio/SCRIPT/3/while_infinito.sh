#!/bin/bash

x=1;

while :
	do 
		
		echo -e "Fermati per favore\n";
		
	done
