#!/bin/bash

echo -e "come vuoi chiamare il tuo file?";
read nome;
touch "$nome";
chmod u+x "$nome";

