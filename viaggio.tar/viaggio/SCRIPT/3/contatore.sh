

echo -e "Che comando vuoi contare?/n";
read input;

VARIABILE=$( history | grep $input | wc -l );
echo -e "il comando $input è stato usato $VARIABILE volte\n";
