#!/bin/bash

echo -e "ciao, quanti file vuoi creare(1-10)?\n";

read num;

if [[ $num -gt 10 || $num -le 0 ]]; then
	echo -e "numero errrato";
	exit;
fi

for i in $( seq 1 $num ); do
	touch file-$i;
	echo -e "vuoi dare permessi di esecuzione al file-$i? Y\/N\ \n";
	read lettera;
	if [ $lettera == "Y" || $lettera == "y"] then
	chmod u+x file-$i;
fi

echo -e "Ho creato file-$i\n";

done
