#!/bin/bash

echo -e "ciao, quanti file vuoi creare?";
read num;
if [ $num -gt 10 ]; then
	echo -e "numero troppo grande";
	exit;
fi

if [ $num -lte 0 ]; then
	echo -e "numero troppo piccolo";
	exit;
fi

if [ $num <= 10 >=1]
	touch "file$num";
	echo -e "Creo il file: file$num\n";
fi
	done;

