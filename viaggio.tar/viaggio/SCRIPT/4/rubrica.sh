#!/bin/bash

while :
	do 
		
		read -p "Vuoi inserire un contatto? [Y/N]" a;
		if [[ $a = "N" || $a = "n" ]];
		then
			break;
		else	
			if [[ $a = "Y" || $a = "y" ]];
		then
		read -p "Inserisci nome" nome;
		read -p "Inserisci telefono" telefono;
		read -p "Inserisci indirizzo" indirizzo;
			break;	
		fi
done
