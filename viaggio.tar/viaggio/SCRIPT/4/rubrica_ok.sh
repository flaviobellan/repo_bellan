#!/bin/bash

echo -e "**RUBRICA**\n";

while :
do
	read -p "[I/i]nserisci o [V/v]isualizza: " lett;
	
	case "$lett" in
	
	[Ii])
		read -p "nome: " name;
		read -p "telefono: " tel;
		read -p "indirizzo: " address;
		echo "$name -- $tel -- $address" >> contatti
	;;
	[Vv])
	more contatti
	;;
	
	*) echo -e "Grazie e arrivederci\n"
	exit;
	;;
	esac;
	
done
