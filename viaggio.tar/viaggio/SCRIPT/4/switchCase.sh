#!/bin/bash

read -p "dammi una lettera [a/b/c/]" lett;

#introduco lo switch

case "$lett" in

[Aa])
	echo -e "Hai inserito una A--> $lett\n"
	;;
	
[Bb])
	echo -e "Hai inserito una B--> $lett\n"
	;;
	
[Cc])
	echo -e "Hai inserito una C--> $lett\n"
	;;
	
	esac;

#come elencare molti if in cascata
