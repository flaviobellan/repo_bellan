#!/bin/bash

for i in $( seq 1 10 ); do
	echo -e "ciao --> $i\n"
	done;

for i in $( ls); do
	echo -e "Il file si chiama: $i\n"
	sleep 1
	done;
