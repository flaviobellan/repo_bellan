#!/bin/bash

# questo è un commento

echo -e "Hello\nWorld!";

# -e dice di eseguire in un certo modo e non letteralmente
# \n significa new line

read name;

sleep 5;

echo -e "Ciao $name\n";




