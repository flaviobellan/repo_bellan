<?php
	$msg="hello Luca!";

	$msg=strtoupper($msg);

	echo$msg;
	?>
	
	<br />
	
	<?php
	echo"In php posso avere istruzioni, funzioni, variabili. Per la variabili, non sono obbligato a inizializzare la variabile, vanno
	forzate";
	?>
	
	<br />
	
	<?php
	$v1=8;
	$v2=4;
	echo $v1+$v2;


?>
	<br />
<?php
//concatenazione

echo "stringa".$v1;
?>
